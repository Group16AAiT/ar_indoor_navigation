package com.example.ar_indoor_nav_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
