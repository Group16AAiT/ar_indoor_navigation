// // import 'package:ar_indoor_nav_admin_app/main.dart';
// import 'package:ar_indoor_nav_admin/main.dart';
// import 'package:flutter/material.dart';

// import 'package:http/http.dart' as http;

// class SignupPage extends StatefulWidget {
//   SignupPage({Key? key}) : super(key: key);

//   @override
//   State<SignupPage> createState() => _SignupPage();
// }

// class _SignupPage extends State<SignupPage> {
//   bool _isloading = false;
//   bool isUserNameValidate = false;
//   bool isUserEmailValidate = false;
//   bool isUserPassValidate = false;

//   final TextEditingController nameController = new TextEditingController();
//   final TextEditingController emailController = new TextEditingController();
//   final TextEditingController passwordController = new TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: new AppBar(
//         backgroundColor: Colors.grey[900],
//         title: new Text(""),
//       ),
//       body: Container(
//         decoration: new BoxDecoration(color: Colors.grey[900]),
//         child: _isloading
//             ? Center(child: CircularProgressIndicator())
//             : ListView(
//                 children: <Widget>[
//                   heardSection(),
//                   textSection(),
//                   buttonSection(),
//                 ],
//               ),
//       ),
//     );
//   }

//   bool isEmail(String em) {
//     String emailRegexp =
//         r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

//     RegExp regExp = RegExp(emailRegexp);

//     return regExp.hasMatch(em);
//   }

//   signUp(String name, String email, password) async {
//     Map data = {'name': name, 'email': email, 'password': password};
//     // enter your local ip address
//     var response = await http.post(
//         // Uri.parse('https://arindoornav.herokuapp.com/signup'),
//         Uri.parse('http://192.168.1.72:8080/signup'),
//         body: data);
//     print('Response Status : ${response.statusCode}');
//     print('Response body: ${response.body}');
//     Navigator.of(context).pushAndRemoveUntil(
//         MaterialPageRoute(builder: (BuildContext context) => MainPage()),
//         (Route<dynamic> route) => false);
//   }

//   Container buttonSection() {
//     return Container(
//         padding: EdgeInsets.symmetric(horizontal: 115.0, vertical: 20),
//         child: ElevatedButton(
//           style: ElevatedButton.styleFrom(
//               primary: Colors.yellowAccent[700],
//               elevation: 3,
//               shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(30)),
//               padding: EdgeInsets.all(20),
//               minimumSize: Size(100, 50)),
//           child: Text(
//             "Add",
//             style: TextStyle(color: Colors.black),
//           ),
//           onPressed: () {
//             if (validateTextField(nameController.text, emailController.text,
//                 passwordController.text)) {
//               setState(() {
//                 _isloading = true;
//               });
//               signUp(nameController.text, emailController.text,
//                   passwordController.text);
//             }
//             return null;
//           },
//         ));
//   }

//   Container textSection() {
//     return Container(
//       padding: EdgeInsets.symmetric(horizontal: 35.0, vertical: 20.0),
//       child: Column(
//         children: <Widget>[
//           TextField(
//             controller: nameController,
//             cursorColor: Colors.white,
//             style: TextStyle(color: Colors.grey[50]),
//             decoration: InputDecoration(
//                 fillColor: Colors.grey[800],
//                 filled: true,
//                 icon: Icon(Icons.person, color: Colors.white70),
//                 hintText: "Name",
//                 errorText:
//                     isUserNameValidate ? 'Please enter a Username' : null,
//                 border: UnderlineInputBorder(
//                     borderRadius: BorderRadius.circular(10.0),
//                     borderSide: BorderSide(color: Colors.white)),
//                 hintStyle: TextStyle(color: Colors.white)),
//           ),
//           SizedBox(height: 30.0),
//           TextField(
//             controller: emailController,
//             cursorColor: Colors.white,
//             style: TextStyle(color: Colors.grey[50]),
//             decoration: InputDecoration(
//                 fillColor: Colors.grey[800],
//                 filled: true,
//                 errorText:
//                     isUserEmailValidate ? 'Please enter valid email' : null,
//                 icon: Icon(Icons.email, color: Colors.white70),
//                 hintText: "Email",
//                 border: UnderlineInputBorder(
//                     borderRadius: BorderRadius.circular(10.0),
//                     borderSide: BorderSide(color: Colors.white)),
//                 hintStyle: TextStyle(color: Colors.white)),
//           ),
//           SizedBox(height: 30.0),
//           TextField(
//             controller: passwordController,
//             cursorColor: Colors.white,
//             style: TextStyle(color: Colors.white),
//             decoration: InputDecoration(
//                 fillColor: Colors.grey[800],
//                 filled: true,
//                 errorText:
//                     isUserPassValidate ? 'Please enter a Password' : null,
//                 icon: Icon(Icons.vpn_key, color: Colors.white70),
//                 hintText: "Password",
//                 border: UnderlineInputBorder(
//                     borderRadius: BorderRadius.circular(10.0),
//                     borderSide: BorderSide(color: Colors.white)),
//                 hintStyle: TextStyle(color: Colors.white)),
//           )
//         ],
//       ),
//     );
//   }

//   Container heardSection() {
//     return Container(
//       margin: EdgeInsets.only(top: 50.0),
//       padding: EdgeInsets.symmetric(horizontal: 85.0, vertical: 30.0),
//       child: Text(
//         "Add Admin",
//         style: TextStyle(color: Colors.white, fontSize: 30.0),
//       ),
//     );
//   }

//   bool validateTextField(String name, String email, String password) {
//     if (name.isEmpty) {
//       setState(() {
//         isUserNameValidate = true;
//       });
//       return false;
//     } else if (email.isEmpty || !isEmail(email)) {
//       setState(() {
//         isUserEmailValidate = true;
//       });
//       return false;
//     } else if (password.isEmpty) {
//       setState(() {
//         isUserPassValidate = true;
//       });
//       return false;
//     }
//     setState(() {
//       isUserNameValidate = false;
//       isUserEmailValidate = false;
//       isUserPassValidate = false;
//     });

//     return true;
//   }
// }
