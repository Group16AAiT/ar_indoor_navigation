// import 'dart:convert';
// // import 'package:ar_indoor_nav_admin_app/main.dart';
// import 'package:ar_indoor_nav_admin/main.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;

// class AuthPage extends StatefulWidget {
//   AuthPage({Key? key}) : super(key: key);

//   @override
//   State<AuthPage> createState() => _AuthPage();
// }

// class _AuthPage extends State<AuthPage> {
//   bool _isloading = false;
//   bool isUserEmailValidate = false;
//   bool isUserPassValidate = false;

//   final TextEditingController emailController = new TextEditingController();
//   final TextEditingController passwordController = new TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Container(
//         decoration: new BoxDecoration(color: Colors.black),
//         child: _isloading
//             ? Center(child: CircularProgressIndicator())
//             : ListView(
//                 children: <Widget>[
//                   SizedBox(height: 80),
//                   Container(
//                     child: Icon(
//                       Icons.lock,
//                       color: Colors.yellow[700],
//                       size: 80,
//                     ),
//                     alignment: Alignment.topCenter,
//                     height: 100.0,
//                     width: 80.0,
//                   ),
//                   //SizedBox(height: 10),
//                   heardSection(),
//                   textSection(),
//                   buttonSection(),
//                 ],
//               ),
//       ),
//     );
//   }

//   bool isEmail(String em) {
//     String emailRegexp =
//         r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

//     RegExp regExp = RegExp(emailRegexp);

//     return regExp.hasMatch(em);
//   }

//   login(String email, password) async {
//     SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
//     Map data = {'email': email, 'password': password};
//     // enter your local ip address
//     // var response = await http
//     //     .post(Uri.parse('https://arindoornav.herokuapp.com/login'), body: data);
//     var response = await http.post(Uri.parse('http://192.168.1.72:8080/login'),
//         body: data);

//     if (response.statusCode == 200) {
//       var jsonResponse = jsonDecode(response.body);
//       print('Response Status : ${response.statusCode}');
//       print('Response body: ${response.body}');
//       if (jsonResponse != null) {
//         setState(() {
//           _isloading = false;
//         });
//         sharedPreferences.setString('token', jsonResponse['token']);
//         Navigator.of(context).pushAndRemoveUntil(
//             MaterialPageRoute(builder: (BuildContext context) => MainPage()),
//             (Route<dynamic> route) => false);
//       }
//     } else {
//       setState(() {
//         _isloading = false;
//       });
//       print(response.body);
//     }
//   }

//   Container buttonSection() {
//     return Container(
//         padding: EdgeInsets.symmetric(horizontal: 115.0, vertical: 20),
//         child: ElevatedButton(
//           style: ElevatedButton.styleFrom(
//               primary: Colors.yellowAccent[700],
//               elevation: 3,
//               shape: RoundedRectangleBorder(
//                   borderRadius: BorderRadius.circular(30)),
//               padding: EdgeInsets.all(20),
//               minimumSize: Size(100, 50)),
//           child: Text(
//             "Login",
//             style: TextStyle(color: Colors.black),
//           ),
//           onPressed: () {
//             if (validateTextField(
//                 emailController.text, passwordController.text)) {
//               setState(() {
//                 _isloading = true;
//               });
//               login(emailController.text, passwordController.text);
//             }
//             return null;
//           },
//         ));
//   }

//   Container textSection() {
//     return Container(
//       padding: EdgeInsets.symmetric(horizontal: 35.0, vertical: 20.0),
//       child: Column(
//         children: <Widget>[
//           TextField(
//             controller: emailController,
//             cursorColor: Colors.white,
//             style: TextStyle(color: Colors.grey[50]),
//             decoration: InputDecoration(
//                 fillColor: Colors.grey[800],
//                 filled: true,
//                 errorText: isUserEmailValidate
//                     ? 'The email doesn’t exist or enter valid email.'
//                     : null,
//                 icon: Icon(Icons.email, color: Colors.white70),
//                 hintText: "Email",
//                 border: UnderlineInputBorder(
//                     borderRadius: BorderRadius.circular(10.0),
//                     borderSide: BorderSide(color: Colors.white)),
//                 hintStyle: TextStyle(color: Colors.white)),
//           ),
//           SizedBox(height: 30.0),
//           TextField(
//             controller: passwordController,
//             cursorColor: Colors.white,
//             style: TextStyle(color: Colors.white),
//             decoration: InputDecoration(
//                 fillColor: Colors.grey[800],
//                 filled: true,
//                 errorText:
//                     isUserPassValidate ? 'please enter your password' : null,
//                 icon: Icon(Icons.vpn_key, color: Colors.white70),
//                 hintText: "Password",
//                 border: UnderlineInputBorder(
//                     borderRadius: BorderRadius.circular(10.0),
//                     borderSide: BorderSide(color: Colors.white)),
//                 hintStyle: TextStyle(color: Colors.white)),
//           )
//         ],
//       ),
//     );
//   }

//   Container heardSection() {
//     return Container(
//       margin: EdgeInsets.only(top: 50.0),
//       padding: EdgeInsets.symmetric(horizontal: 85.0, vertical: 30.0),
//       child: Text(
//         "Welcome",
//         style: TextStyle(
//             color: Colors.white, fontSize: 35.0, fontWeight: FontWeight.bold),
//       ),
//     );
//   }

//   bool validateTextField(String email, String password) {
//     if (email.isEmpty || !isEmail(email)) {
//       setState(() {
//         isUserEmailValidate = true;
//       });
//       setState(() {
//         _isloading = false;
//       });
//       return false;
//     } else if (password.isEmpty) {
//       setState(() {
//         isUserPassValidate = true;
//       });
//       return false;
//     }
//     setState(() {
//       isUserEmailValidate = false;
//       isUserPassValidate = false;
//     });

//     return true;
//   }
// }
