import 'package:ar_indoor_nav_admin/data/account/account.dart';
import 'package:ar_indoor_nav_admin/data/account/bloc/sign_in/sign_in_bloc.dart';
import 'package:ar_indoor_nav_admin/data/account/bloc/sign_up/sign_up_bloc.dart';
import 'package:ar_indoor_nav_admin/data/authentication/authentication.dart';
import 'package:ar_indoor_nav_admin/route.dart';
import 'package:ar_indoor_nav_admin/util/storage/secure_storage.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);

  final AccountRepository authenticationRepository = AccountRepository(
    remoteDataProvider: AccountRemoteDataProvider(httpClient: http.Client()),
    localDataProvider: AccountLocalDataProvider(
      secureStorage: SecureStorage(storage: const FlutterSecureStorage()),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (context) =>
              AuthenticationBloc(accountRepository: authenticationRepository),
        ),
        BlocProvider(
          create: (context) =>
              SignInBloc(accountRepository: authenticationRepository),
        ),
        BlocProvider(
          create: (context) =>
              SignUpBloc(accountRepository: authenticationRepository),
        ),
      ],
      child: MaterialApp(
        title: 'Flutter Demo',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        // home: const MyHomePage(title: 'Flutter Demo Home Page'),
        // home: LoginPage(),
        // home: const BuildingList(),
        // home: const CategoryList(),
        initialRoute: "/",
        onGenerateRoute: PageRouter.generateRoute,
      ),
    );
  }
}
