import 'dart:async';

import 'package:ar_indoor_nav_admin/data/account/repository/account_repository.dart';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'sign_up_event.dart';
part 'sign_up_state.dart';
part 'sign_up_mixins.dart';

class SignUpBloc extends Bloc<SignUpEvent, SignUpState> with _StateMixin {
  final AccountRepository accountRepository;

  SignUpBloc({required this.accountRepository}) : super(InitialSignUpState());

  @override
  Stream<SignUpState> mapEventToState(
    SignUpEvent event,
  ) async* {
    try {
      yield SigningUpState();
      await accountRepository.signUpAdmin(
          event.name, event.email, event.password);
      yield SignedUpState();
    } catch (e) {
      print(e);
    }
  }
}
