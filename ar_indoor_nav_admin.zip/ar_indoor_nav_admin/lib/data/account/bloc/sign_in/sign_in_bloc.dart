import 'dart:async';

import 'package:ar_indoor_nav_admin/data/account/repository/account_repository.dart';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

part 'sign_in_event.dart';
part 'sign_in_state.dart';

class SignInBloc extends Bloc<SignInEvent, SignInState> {
  final AccountRepository accountRepository;

  SignInBloc({required this.accountRepository}) : super(InitialSignInState());

  @override
  Stream<SignInState> mapEventToState(
    SignInEvent event,
  ) async* {
    try {
      yield SigningInState();
      await accountRepository.signIn(event.email, event.password);
      yield SignedInState();
    } catch (e) {
      print(e);
    }
  }
}
