import 'package:ar_indoor_nav_admin/data/account/data_provider/account_local_provider.dart';
import 'package:ar_indoor_nav_admin/data/account/data_provider/account_remote_provider.dart';
import 'package:meta/meta.dart';

class AccountRepository {
  final AccountRemoteDataProvider remoteDataProvider;
  final AccountLocalDataProvider localDataProvider;

  AccountRepository({
    required this.remoteDataProvider,
    required this.localDataProvider,
  });

  Future<void> signUpAdmin(String name, String email, String password) async {
    String token = await remoteDataProvider.signUpAdmin(name, email, password);

    return _saveToken(token);
  }

  Future<void> signIn(String email, String password) async {
    String token = await remoteDataProvider.signIn(email, password);
    return _saveToken(token);
  }

  Future<void> _saveToken(String token) {
    return localDataProvider.write(token);
  }

  Future<bool> isSignedIn() async => (await localDataProvider.read()) != null;

  Future<void> signOut() async {
    await localDataProvider.delete();
  }
}
