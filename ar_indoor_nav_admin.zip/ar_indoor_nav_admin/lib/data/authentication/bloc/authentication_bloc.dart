import 'dart:async';
import 'package:ar_indoor_nav_admin/data/account/repository/account_repository.dart';
import 'package:equatable/equatable.dart';
import 'package:bloc/bloc.dart';
part 'authentication_event.dart';
part 'authentication_state.dart';

class AuthenticationBloc
    extends Bloc<AuthenticationEvent, AuthenticationState> {
  final AccountRepository accountRepository;
  AuthenticationBloc({required this.accountRepository}) : super(UnknownState());
  @override
  Stream<AuthenticationState> mapEventToState(
    AuthenticationEvent event,
  ) async* {
    switch (event) {
      case AuthenticationEvent.getAuthState:
        {
          if (await isSignedIn) {
            // yield AuthenticationState.authenticated;
            yield AuthenticatedState();
          } else {
            yield UnAuthenticatedState();
            // yield AuthenticationState.unauthenticated;
          }
          break;
        }
      case AuthenticationEvent.authenticate:
        yield AuthenticatedState();
        // yield AuthenticationState.authenticated;
        break;
      case AuthenticationEvent.unAuthenticate:
        await accountRepository.signOut();
        yield UnAuthenticatedState();
        // yield AuthenticationState.unauthenticated;
        break;
    }
  }

  Future<bool> get isSignedIn async => await accountRepository.isSignedIn();
}
