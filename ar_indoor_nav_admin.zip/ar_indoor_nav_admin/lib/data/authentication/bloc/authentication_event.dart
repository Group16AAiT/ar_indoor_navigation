part of 'authentication_bloc.dart';

enum AuthenticationEvent { getAuthState, authenticate, unAuthenticate }
