// // import 'package:ar_indoor_nav_admin_app/pages/SignupPage.dart';
// import 'package:ar_indoor_nav_admin/pages/LoginPage.dart';
// import 'package:ar_indoor_nav_admin/pages/SignupPage.dart';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// // import 'pages/LoginPage.dart';

// void main() {
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   // This widget is the root of your application.
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       color: Colors.red,
//       title: 'Admin Page',
//       home: MainPage(),
//     );
//   }
// }

// class MainPage extends StatefulWidget {
//   final int? id;
//   final String? name;

//   const MainPage({this.id, this.name});

//   @override
//   State<MainPage> createState() => _MainPageState();
// }

// class _MainPageState extends State<MainPage> {
//   @override
//   void initState() {
//     super.initState();
//     checkLoginStatus();
//   }

//   checkLoginStatus() async {
//     final sharedPreferences = await SharedPreferences.getInstance();
//     if (sharedPreferences.getString("token") == null) {
//       Navigator.of(context).pushAndRemoveUntil(
//           MaterialPageRoute(builder: (BuildContext context) => AuthPage()),
//           (Route<dynamic> route) => false);
//     }
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar: AppBar(
//           backgroundColor: Colors.grey[900],
//           title: Text("Admin Page", style: TextStyle(color: Colors.white)),
//         ),
//         body: Container(
//             decoration: new BoxDecoration(color: Colors.grey[900]),
//             child: Center(
//               child: Text(
//                 'Buildings  Page',
//                 style: TextStyle(color: Colors.white, fontSize: 20),
//               ),
//             )),
//         drawer: Drawer(
//           child: new ListView(
//             children: <Widget>[
//               new UserAccountsDrawerHeader(
//                   decoration: new BoxDecoration(color: Colors.grey[850]),
//                   accountName: new Text("Admin Name"),
//                   accountEmail: new Text("admin@email.com")),
//               new ListTile(
//                 title: new Text("Add Admin"),
//                 trailing: new Icon(Icons.add),
//                 onTap: () => Navigator.of(context).push(new MaterialPageRoute(
//                     builder: (BuildContext context) => SignupPage())),
//               ),
//               new ListTile(
//                 title: new Text(" Admins"),
//                 trailing: new Icon(Icons.person),
//                 onTap: () => Navigator.of(context).push(new MaterialPageRoute(
//                     builder: (BuildContext context) => MainPage())),
//               ),
//               new ListTile(
//                 title: new Text("Logout"),
//                 trailing: new Icon(Icons.privacy_tip),
//                 onTap: () async {
//                   final sharedPreferences =
//                       await SharedPreferences.getInstance();
//                   sharedPreferences.clear();
//                   sharedPreferences.commit();
//                   checkLoginStatus();
//                 },
//               ),
//             ],
//           ),
//         ));
//   }
// }
